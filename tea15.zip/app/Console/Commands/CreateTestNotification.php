<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TeaTimetable;
use App\Models\User;

class CreateTestNotification extends Command
{
    protected $signature = 'tea:test-notification {chatId=1012190593}';
    protected $description = 'Create a test tea timetable with current time and real tea for immediate notification testing';

    public function handle()
    {
        $chatId = $this->argument('chatId');
        
        $this->info('🍵 Creating test notification...');
        
        // Get the first user
        $user = User::first();
        if (!$user) {
            $this->error('❌ No users found in database!');
            return 1;
        }
        
        $this->info('👤 User: ' . $user->name . ' (ID: ' . $user->id . ')');
        
        // Create a timetable with current time and real tea
        $currentTime = now('Asia/Kuala_Lumpur')->format('H:i');
        $this->info('⏰ Setting tea time for: ' . $currentTime);
        
        // Create a test timetable with current time and real tea
        $timetable = $user->teaTimetables()->create([
            'title' => 'Test Notification Schedule',
            'description' => 'Test timetable for immediate Telegram notifications',
            'start_date' => now()->format('Y-m-d'),
            'end_date' => now()->addDays(7)->format('Y-m-d'),
            'timezone' => 'Asia/Kuala_Lumpur',
            'schedule' => [
                [
                    'day' => strtolower(now()->format('l')), // Today's day
                    'times' => [
                        [
                            'time' => $currentTime, // Current time
                            'tea_id' => 2, // Green Tea (real tea ID)
                            'notes' => 'Test notification - Green Tea time!'
                        ]
                    ]
                ]
            ],
            'is_active' => true,
            'telegram_notifications_enabled' => true,
            'telegram_chat_id' => $chatId,
        ]);
        
        $this->info('✅ Test notification timetable created successfully!');
        $this->info('📋 Timetable ID: ' . $timetable->id);
        $this->info('🍵 Tea: Green Tea (ID: 2)');
        $this->info('📅 Schedule for: ' . ucfirst($timetable->schedule[0]['day']));
        $this->info('⏰ Time: ' . $timetable->schedule[0]['times'][0]['time']);
        $this->info('💬 Chat ID: ' . $timetable->telegram_chat_id);
        
        // Test if it's eligible for reminders
        $isActiveForDate = $timetable->isActiveForDate();
        $this->info('🗓️ Active for today: ' . ($isActiveForDate ? 'Yes' : 'No'));
        
        $this->info('🧪 Run this command NOW to test notifications:');
        $this->info('   php artisan tea:send-reminders --test');
        
        return 0;
    }
}
