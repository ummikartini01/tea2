
<?php $__env->startSection('content'); ?>

<div class="mb-8">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold mb-2" style="color: var(--text-dark);">
                🍃 Search Results
            </h1>
            <p class="text-lg" style="color: var(--text-light);">
                Found <?php echo e($teas->count()); ?> teas for "<span style="color: var(--accent-green);"><?php echo e($query); ?></span>"
            </p>
        </div>
        
        <a href="<?php echo e(route('user.dashboard')); ?>" class="btn-secondary">
            ← Back to Dashboard
        </a>
    </div>
</div>

<?php if($teas->count() > 0): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__currentLoopData = $teas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tea-card overflow-hidden">
                <?php
                    $fallbackImage = 'https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?w=600&h=400&fit=crop';
                    $imgSrc = $tea->image
                        ? (str_starts_with($tea->image, 'http') ? $tea->image
                            : (str_starts_with($tea->image, '//') ? 'https:'.$tea->image
                            : (str_starts_with($tea->image, '/storage/') ? $tea->image : '/storage/'.$tea->image)))
                        : $fallbackImage;
                ?>
                
                <div class="relative h-48 overflow-hidden">
                    <img src="<?php echo e($imgSrc); ?>" 
                         class="w-full h-full object-cover transition-transform duration-300 hover:scale-110" 
                         alt="<?php echo e($tea->name); ?>">
                    
                    <div class="absolute top-3 right-3">
                        <span class="flavor-tag">
                            <?php echo e($tea->flavor); ?>

                        </span>
                    </div>
                </div>

                <div class="p-6">
                    <h3 class="text-xl font-bold mb-2" style="color: var(--text-dark);">
                        <?php echo e($tea->name); ?>

                    </h3>

                    <div class="space-y-2 mb-4">
                        <div class="flex items-center justify-between">
                            <span class="text-sm font-medium" style="color: var(--text-medium);">Flavor</span>
                            <span class="text-sm" style="color: var(--text-light);"><?php echo e($tea->flavor); ?></span>
                        </div>
                        <div class="flex items-center justify-between">
                            <span class="text-sm font-medium" style="color: var(--text-medium);">Caffeine</span>
                            <span class="text-sm" style="color: var(--text-light);"><?php echo e($tea->caffeine_level); ?></span>
                        </div>
                    </div>

                    <div class="mb-4">
                        <p class="text-sm line-clamp-2" style="color: var(--text-light);">
                            <?php echo e($tea->health_benefit); ?>

                        </p>
                    </div>

                    <!-- Rating Section -->
                    <div class="pt-4 border-t" style="border-color: var(--border-color);">
                        <!-- Average Rating Display -->
                        <div class="flex items-center justify-between mb-3">
                            <div class="flex items-center space-x-2">
                                <span class="text-sm font-medium" style="color: var(--text-medium);">
                                    <?php echo e(number_format($tea->average_rating, 1)); ?>

                                </span>
                                <span class="text-yellow-500">⭐</span>
                                <span class="text-xs" style="color: var(--text-light);">
                                    (<?php echo e($tea->total_ratings); ?> reviews)
                                </span>
                            </div>
                        </div>

                        <!-- User Rating Form -->
                        <form action="<?php echo e(route('ratings.store')); ?>" method="POST" class="rating-form" data-tea-id="<?php echo e($tea->id); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="tea_id" value="<?php echo e($tea->id); ?>">
                            
                            <?php if($tea->user_rating): ?>
                                <div class="text-sm text-green-600 mb-2">
                                    You rated: <?php echo e($tea->user_rating->rating); ?> ⭐
                                </div>
                            <?php endif; ?>

                            <div class="flex items-center space-x-2">
                                <label class="text-sm" style="color: var(--text-medium);">Rate:</label>
                                <select name="rating" class="border rounded px-2 py-1 text-sm" style="border-color: var(--border-color);">
                                    <option value="">Select rating</option>
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e($tea->user_rating && $tea->user_rating->rating == $i ? 'selected' : ''); ?>>
                                            <?php echo e($i); ?> - <?php if($i == 1): ?> Poor <?php elseif($i == 2): ?> Fair <?php elseif($i == 3): ?> Good <?php elseif($i == 4): ?> Very Good <?php else: ?> Excellent <?php endif; ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            
                            <button type="submit" class="mt-2 btn-primary text-sm px-3 py-1">
                                <?php echo e($tea->user_rating ? 'Update' : 'Submit'); ?>

                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <div class="text-center py-16">
        <div class="max-w-md mx-auto">
            <div class="w-24 h-24 mx-auto mb-6 rounded-full flex items-center justify-center" style="background: var(--cream-green);">
                <span class="text-4xl">🔍</span>
            </div>
            
            <h3 class="text-2xl font-bold mb-4" style="color: var(--text-dark);">
                No teas found
            </h3>
            
            <p class="text-lg mb-6" style="color: var(--text-light);">
                We couldn't find any teas matching "<span style="color: var(--accent-green);"><?php echo e($query); ?></span>"
            </p>
            
            <div class="space-y-3">
                <a href="<?php echo e(route('find.tea')); ?>" class="btn-primary block">
                    Try Personalized Recommendations
                </a>
                <a href="<?php echo e(route('user.dashboard')); ?>" class="btn-secondary block">
                    Back to Dashboard
                </a>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laragon\laragon\www\tea2\resources\views/user/search-results.blade.php ENDPATH**/ ?>