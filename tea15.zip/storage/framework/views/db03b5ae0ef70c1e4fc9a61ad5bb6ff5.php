

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <div class="flex justify-between items-start mb-4">
        <div>
            <h1 class="text-3xl font-bold mb-2">Scraped Teas</h1>
            <p class="text-gray-600">Manage and edit scraped tea data</p>
        </div>
        <div class="space-x-4">
            <form action="<?php echo e(route('admin.scrape.teas')); ?>" method="POST" class="inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                    🕷️ Scrap Tea Data
                </button>
            </form>
            <a href="<?php echo e(route('admin.teas.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 inline-block">
                ➕ Add New Tea
            </a>
        </div>
    </div>
    
    <!-- Flavor Filter -->
    <div class="bg-white rounded-lg shadow p-4">
        <form method="GET" action="<?php echo e(route('admin.teas.scraped')); ?>" class="flex items-center gap-4">
            <div class="flex items-center gap-2">
                <label for="flavor" class="text-sm font-medium text-gray-700">
                    🍃 Filter by Flavor:
                </label>
                <select name="flavor" id="flavor" class="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <option value="all" <?php echo e($flavorFilter === 'all' ? 'selected' : ''); ?>>
                        All Flavors (<?php echo e($teas->count()); ?>)
                    </option>
                    <?php $__currentLoopData = $availableFlavors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flavor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $count = \App\Models\Tea::where('source', 'scraped')->where('flavor', $flavor)->count();
                        ?>
                        <option value="<?php echo e($flavor); ?>" <?php echo e($flavorFilter === $flavor ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($flavor)); ?> (<?php echo e($count); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <button type="submit" class="bg-gray-600 text-white px-4 py-2 rounded text-sm hover:bg-gray-700">
                🔍 Apply Filter
            </button>
            
            <?php if($flavorFilter !== 'all'): ?>
                <a href="<?php echo e(route('admin.teas.scraped')); ?>" class="bg-gray-200 text-gray-700 px-4 py-2 rounded text-sm hover:bg-gray-300 inline-block">
                    ✖️ Clear Filter
                </a>
            <?php endif; ?>
        </form>
        
        <?php if($flavorFilter !== 'all'): ?>
            <div class="mt-3 flex items-center justify-between">
                <div class="text-sm text-gray-600">
                    Showing <span class="font-semibold text-blue-600"><?php echo e($teas->count()); ?></span> teas with flavor: 
                    <span class="font-semibold text-blue-600"><?php echo e(ucfirst($flavorFilter)); ?></span>
                </div>
                <div class="text-xs text-gray-500">
                    Total scraped teas: <?php echo e(\App\Models\Tea::where('source', 'scraped')->count()); ?>

                </div>
            </div>
        <?php else: ?>
            <div class="mt-3 text-xs text-gray-500 text-right">
                Total scraped teas: <?php echo e(\App\Models\Tea::where('source', 'scraped')->count()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
    <?php $__empty_1 = true; $__currentLoopData = $teas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white rounded shadow overflow-hidden">
            <?php
                $fallbackImage = 'https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?w=600&h=400&fit=crop';
                $imgSrc = $tea->image
                    ? (str_starts_with($tea->image, 'http') ? $tea->image
                        : (str_starts_with($tea->image, '//') ? 'https:'.$tea->image
                        : (str_starts_with($tea->image, '/storage/') ? $tea->image : '/storage/'.$tea->image)))
                    : $fallbackImage;
            ?>
            <img src="<?php echo e($imgSrc); ?>" alt="<?php echo e($tea->name); ?>" class="w-full h-48 object-cover">
            <div class="p-4">
                <div class="flex items-start justify-between gap-3">
                    <h2 class="text-lg font-semibold text-gray-900 leading-tight"><?php echo e($tea->name); ?></h2>
                    <div class="flex items-center gap-2 shrink-0">
                        <a href="<?php echo e(route('admin.teas.edit', $tea->id)); ?>" class="text-blue-600 hover:text-blue-900">
                            ✏️
                        </a>
                        <form action="<?php echo e(route('admin.teas.destroy', $tea->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure?')">
                                🗑️
                            </button>
                        </form>
                    </div>
                </div>

                <div class="mt-3 space-y-2 text-sm">
                    <div class="flex items-center justify-between">
                        <span class="font-medium text-gray-700">Flavor:</span>
                        <?php if($flavorFilter !== 'all' && $tea->flavor === $flavorFilter): ?>
                            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                🍃 <?php echo e($tea->flavor); ?>

                            </span>
                        <?php else: ?>
                            <span class="text-gray-600"><?php echo e($tea->flavor); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="font-medium text-gray-700">Caffeine:</span>
                        <span class="text-gray-600"><?php echo e($tea->caffeine_level); ?></span>
                    </div>
                    <div>
                        <span class="font-medium text-gray-700 block mb-1">Benefit:</span>
                        <span class="text-gray-600 text-xs leading-relaxed"><?php echo e(Str::limit($tea->health_benefit, 80)); ?></span>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-full bg-white rounded shadow p-6 text-center text-gray-500">
            No scraped teas found. Use the "Scrape Tea Data" button to get started.
        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laragon\laragon\www\tea2\resources\views/admin/teas/scraped.blade.php ENDPATH**/ ?>