<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <div class="flex items-center">
        <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="text-gray-600 hover:text-gray-900 mr-4">
            ← Back to User
        </a>
        <h1 class="text-3xl font-bold">Ratings by <?php echo e($user->name); ?></h1>
    </div>
</div>

<!-- User Info Summary -->
<div class="bg-white rounded-lg shadow p-6 mb-6">
    <div class="flex items-center">
        <div class="flex-shrink-0 h-12 w-12">
            <div class="h-12 w-12 rounded-full bg-blue-500 flex items-center justify-center">
                <span class="text-white text-lg font-bold">
                    <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                </span>
            </div>
        </div>
        <div class="ml-4">
            <h2 class="text-lg font-semibold text-gray-900"><?php echo e($user->name); ?></h2>
            <p class="text-gray-600"><?php echo e($user->email); ?></p>
            <div class="mt-2 flex items-center space-x-4 text-sm text-gray-500">
                <span>Total Ratings: <?php echo e($ratings->count()); ?></span>
                <span>Average: <?php echo e($ratings->avg('rating') ? number_format($ratings->avg('rating'), 1) : '0.0'); ?>/5</span>
                <span>Joined: <?php echo e($user->created_at->format('M j, Y')); ?></span>
            </div>
        </div>
    </div>
</div>

<!-- Ratings List -->
<div class="bg-white rounded-lg shadow overflow-hidden">
    <div class="p-4 border-b border-gray-200">
        <div class="flex items-center justify-between">
            <h2 class="text-lg font-semibold">All Ratings (<?php echo e($ratings->count()); ?>)</h2>
            <div class="text-sm text-gray-500">
                User's complete rating history
            </div>
        </div>
    </div>
    
    <?php if($ratings->count() > 0): ?>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Tea
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Rating
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Description
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Date
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900"><?php echo e($rating->tea->name); ?></div>
                                <div class="text-xs text-gray-500"><?php echo e($rating->tea->flavor); ?> • <?php echo e($rating->tea->caffeine_level); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-lg font-bold text-blue-600">
                                    <?php echo e($rating->rating); ?>/5
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-sm text-gray-900 max-w-xs">
                                    <?php echo e($rating->description ?: 'No description'); ?>

                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo e($rating->created_at->format('M j, Y g:i A')); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="<?php echo e(route('admin.ratings.edit', $rating->id)); ?>" 
                                       class="text-indigo-600 hover:text-indigo-900" title="Edit">
                                        ✏️
                                    </a>
                                    <form action="<?php echo e(route('admin.ratings.destroy', $rating->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900" 
                                                onclick="return confirm('Are you sure you want to delete this rating?')" 
                                                title="Delete">
                                            🗑️
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="text-center py-8">
            <div class="text-gray-400 text-4xl mb-2">⭐</div>
            <p class="text-gray-500"><?php echo e($user->name); ?> hasn't rated any teas yet.</p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laragon\laragon\www\tea2\resources\views/admin/ratings/by-user.blade.php ENDPATH**/ ?>