<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <!-- Header -->
    <div class="mb-6">
        <div class="flex items-center justify-between mb-4">
            <div>
                <h1 class="text-3xl font-bold mb-2">Edit Tea Timetable</h1>
                <p class="text-gray-600">Update your tea schedule and preferences</p>
            </div>
        </div>
        
        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>

    <form method="POST" action="<?php echo e(route('user.tea-timetables.update', $teaTimetable)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <!-- Basic Information -->
        <div class="tea-card p-6 mb-6">
            <h2 class="text-xl font-semibold mb-4">Basic Information</h2>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label for="title" class="block text-sm font-medium text-gray-700 mb-2">
                        Title <span class="text-red-500">*</span>
                    </label>
                    <input type="text" 
                           id="title" 
                           name="title" 
                           value="<?php echo e(old('title', $teaTimetable->title)); ?>"
                           class="search-bar"
                           required>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="timezone" class="block text-sm font-medium text-gray-700 mb-2">
                        Timezone <span class="text-red-500">*</span>
                    </label>
                    <select id="timezone" name="timezone" class="search-bar" required>
                        <?php $__currentLoopData = $timezones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('timezone', $teaTimetable->timezone) == $value ? 'selected' : ''); ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['timezone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="start_date" class="block text-sm font-medium text-gray-700 mb-2">
                        Start Date <span class="text-red-500">*</span>
                    </label>
                    <input type="date" 
                           id="start_date" 
                           name="start_date" 
                           value="<?php echo e(old('start_date', $teaTimetable->start_date->format('Y-m-d'))); ?>"
                           class="search-bar"
                           required>
                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="end_date" class="block text-sm font-medium text-gray-700 mb-2">
                        End Date (optional)
                    </label>
                    <input type="date" 
                           id="end_date" 
                           name="end_date" 
                           value="<?php echo e(old('end_date', $teaTimetable->end_date ? $teaTimetable->end_date->format('Y-m-d') : '')); ?>"
                           class="search-bar">
                    <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="mt-6">
                <label for="description" class="block text-sm font-medium text-gray-700 mb-2">
                    Description
                </label>
                <textarea id="description" 
                          name="description" 
                          rows="3"
                          class="search-bar"
                          placeholder="Describe your tea schedule..."><?php echo e(old('description', $teaTimetable->description)); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <!-- Simple Schedule Input -->
        <div class="tea-card p-6 mb-6">
            <h2 class="text-xl font-semibold mb-4">🍵 Tea Schedule</h2>
            <p class="text-gray-600 mb-4">Enter your schedule data in JSON format</p>
            
            <div class="mb-4">
                <label for="schedule_json" class="block text-sm font-medium text-gray-700 mb-2">
                    Schedule Data (JSON)
                </label>
                <textarea id="schedule_json" 
                          name="schedule" 
                          rows="8"
                          class="search-bar font-mono text-sm"
                          placeholder='[{"day": "monday", "times": [{"time": "09:00", "tea_id": "1", "notes": "Morning tea"}]}]'><?php echo e(old('schedule', json_encode($teaTimetable->schedule, JSON_PRETTY_PRINT))); ?></textarea>
                <?php $__errorArgs = ['schedule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <p class="mt-2 text-sm text-gray-500">
                    Format: [{"day": "monday", "times": [{"time": "09:00", "tea_id": "1", "notes": "Morning tea"}]}]
                </p>
            </div>
        </div>

        <!-- Telegram Settings -->
        <div class="tea-card p-6 mb-6">
            <h2 class="text-xl font-semibold mb-4">📱 Telegram Notifications</h2>
            
            <div class="space-y-4">
                <div class="flex items-center">
                    <input type="checkbox" 
                           id="telegram_notifications_enabled" 
                           name="telegram_notifications_enabled" 
                           value="1"
                           <?php echo e(old('telegram_notifications_enabled', $teaTimetable->telegram_notifications_enabled) ? 'checked' : ''); ?>

                           class="mr-2">
                    <label for="telegram_notifications_enabled" class="text-sm font-medium text-gray-700">
                        Enable Telegram notifications
                    </label>
                </div>

                <div id="telegramSettings" <?php echo e(old('telegram_notifications_enabled', $teaTimetable->telegram_notifications_enabled) ? '' : 'class="hidden"'); ?>>
                    <label for="telegram_chat_id" class="block text-sm font-medium text-gray-700 mb-2">
                        Telegram Chat ID
                    </label>
                    <input type="text" 
                           id="telegram_chat_id" 
                           name="telegram_chat_id" 
                           value="<?php echo e(old('telegram_chat_id', $teaTimetable->telegram_chat_id)); ?>"
                           class="search-bar"
                           placeholder="Your Telegram chat ID">
                    <?php $__errorArgs = ['telegram_chat_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <!-- Form Actions -->
        <div class="flex items-center justify-between">
            <a href="<?php echo e(route('user.tea-timetables.index')); ?>" class="text-gray-600 hover:text-gray-900">
                Cancel
            </a>
            <button type="submit" class="btn-primary">
                Update Timetable
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const telegramCheckbox = document.getElementById('telegram_notifications_enabled');
    const telegramSettings = document.getElementById('telegramSettings');
    
    if (telegramCheckbox && telegramSettings) {
        telegramCheckbox.addEventListener('change', function() {
            telegramSettings.classList.toggle('hidden', !this.checked);
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laragon\laragon\www\tea2\resources\views/user/tea-timetables/edit-simple.blade.php ENDPATH**/ ?>