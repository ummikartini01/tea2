

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold">Edit Tea</h1>
        <a href="<?php echo e(route('admin.teas.index')); ?>" class="text-blue-600 hover:text-blue-800">
            ← Back to Teas
        </a>
    </div>
</div>

<div class="bg-white rounded shadow p-6 max-w-2xl">
    <form action="<?php echo e(route('admin.teas.update', $tea->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label class="block text-sm font-medium text-gray-700">Name</label>
            <input type="text" name="name" value="<?php echo e(old('name', $tea->name)); ?>" class="mt-1 block w-full border-gray-300 rounded" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Flavor</label>
            <input type="text" name="flavor" value="<?php echo e(old('flavor', $tea->flavor)); ?>" class="mt-1 block w-full border-gray-300 rounded">
            <?php $__errorArgs = ['flavor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Caffeine Level</label>
            <input type="text" name="caffeine_level" value="<?php echo e(old('caffeine_level', $tea->caffeine_level)); ?>" class="mt-1 block w-full border-gray-300 rounded">
            <?php $__errorArgs = ['caffeine_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Health Benefit</label>
            <input type="text" name="health_benefit" value="<?php echo e(old('health_benefit', $tea->health_benefit)); ?>" class="mt-1 block w-full border-gray-300 rounded">
            <?php $__errorArgs = ['health_benefit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Current Image</label>
            <div class="mt-2">
                <img src="<?php echo e(($tea->image && str_starts_with($tea->image, 'http')) ? $tea->image : (($tea->image && str_starts_with($tea->image, '//')) ? ('https:'.$tea->image) : (($tea->image && str_starts_with($tea->image, '/storage/')) ? $tea->image : ($tea->image ? ('/storage/'.$tea->image) : '')))); ?>" alt="<?php echo e($tea->name); ?>" class="w-48 h-32 object-cover rounded">
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Replace Image (optional)</label>
            <input type="file" name="image" class="mt-1 block w-full" accept="image/*">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="pt-2">
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                Update Tea
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laragon\laragon\www\tea2\resources\views/admin/teas/edit.blade.php ENDPATH**/ ?>